# 🎨 Colors Choice Game (Python)

A fun and interactive **command-line game** where the player picks a color, and the computer randomly picks one too.  
If both colors match — 🎉 **you win the round!**

---

## 🚀 Features
✅ Randomized computer color generation using Python’s `random` module  
✅ Real-time score tracking (player vs computer)  
✅ Input validation (ensures only numbers between 1–5)  
✅ Simple, clean, and user-friendly interface  
✅ Replay option after each round  
✅ Beginner-friendly — easy to understand and modify  

---

## 🕹️ How to Play
1. Run the Python file:
   ```bash
   python color_game.py


2. Choose a color number between 1–5:
| Number | Color     |
| :----: | :-------- |
|    1   | 🔴 Red    |
|    2   | 🟡 Yellow |
|    3   | 🟠 Orange |
|    4   | 🟢 Green  |
|    5   | 🔵 Blue   |


3.If your color matches the computer’s color → You win 🎯
4.Otherwise → The computer wins 😅
5.After each round, you can choose to play again or exit.


💻 Example Output
------------------------------------------------------------------
Winning Rules of the Colors Game:
Enter a number from 1 to 5 and match the computer’s choice to win!

Enter your choice (1–5): 3
🎨 You chose: Orange
💻 Computer chose: Blue
❌ Computer wins this round!

Scores - You: 0 | Computer: 1
Play Again? (Y/N): y

Enter your choice (1–5): 4
🎨 You chose: Green
💻 Computer chose: Green
✅ You win this round!

Scores - You: 1 | Computer: 1
Play Again? (Y/N): n

Game Tied
Thanks for Playing!


⚙️ Installation & Setup
-------------------------------------------------------------
Make sure Python 3.x is installed on your system.
You can verify it by running: python --version


Clone this repository:
git clone https://github.com/<your-username>/color-choice-game.git


Navigate to the folder:
cd color-choice-game


Run the game:
python color_game.py


🧰 Technologies Used
--------------------------------------------------------------
Python 3
Random library (for color generation)
Command-line Interface (CLI)


🧠 Concepts Used
--------------------------------------------------------------
Loops (while, for)
Conditional statements (if, elif, else)
Dictionaries (for color mapping)
Random number generation (random.randint)
Input validation
Functionality design & user interaction


🏁 Future Improvements
--------------------------------------------------------------
✨ Add a graphical version using Tkinter
✨ Add player name input and multi-round mode
✨ Save scores to a text or CSV file
✨ Create a web version using Flask or Streamlit


💬 Support & Feedback
--------------------------------------------------------------
I truly appreciate your interest in this project 💙
If you found it useful or fun:

⭐ Star this repository to show your support
👥 Follow me on GitHub for more beginner-friendly and data-driven projects
📨 Share your feedback, ideas, or suggestions — I’d love to hear how it can be improved!

📧 For feedback or collaboration:
email me directly at your - rayaharish47@gmail.com