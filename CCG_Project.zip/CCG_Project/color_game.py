"""
🎨 Colors Choice Game
---------------------
A fun Python program where the player picks a color (represented by a number 1–5),
and the computer randomly picks one too. If both choices match, the player wins
that round!

📌 Features:
- Randomized computer color selection.
- Score tracking for both player and computer.
- Input validation.
- Option to replay or quit the game.

Author: R.Harish
Date: October 2025
"""

import random  # Import the random module for generating computer’s random choice

# --- Display Game Instructions ---
print('🎯 Winning Rules of the Colors Game:')
print('Enter a number from 1 to 5 and try to match the computer’s choice to win!\n')

# Initialize player and computer scores
player_score = 0
computer_score = 0

# Dictionary to map numbers to color names
colors = {
    1: 'Red',
    2: 'Yellow',
    3: 'Orange',
    4: 'Green',
    5: 'Blue'
}

# --- Main Game Loop ---
while True:
    # Show color menu
    print("Choose your color:")
    for key, value in colors.items():
        print(f"{key}. {value}")

    # Take user input and validate
    player_choice = int(input("\nEnter your choice (1-5): "))
    while player_choice < 1 or player_choice > 5:
        player_choice = int(input("❌ Invalid choice! Enter a number between 1 and 5: "))

    # Get the color name from the dictionary
    player_color = colors[player_choice]
    print(f"\n🎨 You chose: {player_color}")

    # Computer randomly chooses a color
    computer_choice = random.randint(1, 5)
    computer_color = colors[computer_choice]
    print(f"💻 Computer chose: {computer_color}")

    # Compare both choices
    if player_color == computer_color:
        player_score += 1
        print("✅ You win this round!")
    else:
        computer_score += 1
        print("❌ Computer wins this round!")

    # Display updated scores
    print(f"\n🏆 Current Scores → You: {player_score} | Computer: {computer_score}\n")

    # Ask if the player wants to continue
    play_again = input("Play Again? (Y/N): ").lower()
    if play_again == 'n':
        break  # Exit the game loop

# --- Display Final Results ---
print("\n🎮 Final Results 🎮")
if computer_score == player_score:
    print("🤝 Game Tied — Well played!")
elif computer_score < player_score:
    print("🏅 Congratulations! You are the winner!")
else:
    print("💻 Computer wins the game! Better luck next time!")

print("\nThanks for playing the Colors Choice Game! 🎨✨")


